import {useFragmentViewer} from "@wakecap/core-ui/fragment-viewer";
import {useEffect} from "react";

/**
 * Webcam head-tracking parallax for the 3D model viewer.
 *
 * Moving your head in front of the laptop camera gently shifts the view (and leaning in/out zooms),
 * giving the model a sense of depth. Off by default (needs camera permission); toggled from the toolbar.
 *
 * Routed through camera-controls' **focal offset** — an absolute, non-destructive channel that composes
 * with orbiting and reverts with a single call. So it never jumps: it starts from the CURRENT view
 * (offset 0) and just layers the head motion on top; orbit stays live, and toggling off restores the
 * view with zero residual.
 *
 * Tracking: Google's MediaPipe FaceLandmarker (@mediapipe/tasks-vision, Apache-2.0), loaded from CDN at
 * runtime (no added dependency). We own the <video>, the getUserMedia stream (stopped on toggle-off),
 * and the detection loop.
 */

const V = "1.0.1";
const TASKS_VISION_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${V}/vision_bundle.mjs`;
const WASM_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${V}/wasm`;
const MODEL_URL =
	"https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";

// FaceMesh outer eye-corner landmark indices (468-pt mesh).
const R_EYE_OUTER = 33;
const L_EYE_OUTER = 263;

// Pan strength: fraction of the model's radius the view trucks at full head deflection.
const OFFSET_FACTOR = 0.5;
// Zoom strength: fraction of the model's radius the view dollies at a full head lean in/out.
const Z_FACTOR = 0.5;
// EMA smoothing per detection frame (0..1). Lower = smoother/floatier, higher = snappier.
const SMOOTH = 0.3;
// Ignore sub-threshold jitter around centre.
const DEADZONE = 0.02;
// Sign flips — one-char +1/-1 each. MIRROR_X: left/right. INVERT_Y: up/down. INVERT_Z: zoom sense.
const MIRROR_X = 1;
const INVERT_Y = -1;
const INVERT_Z = -1;

const clamp = (v: number) => (v < -1 ? -1 : v > 1 ? 1 : v);

export function useHeadParallax(enabled: boolean) {
	const {state, api} = useFragmentViewer();

	useEffect(() => {
		if (!enabled || state.status !== "ready") return;
		const world = api.viewport()?.world;
		if (!world) return;
		const controls = world.camera.controls;

		// Scale the sway to the model so it reads the same on any building.
		const box = api.bounds();
		let gain = 1;
		let zGain = 1;
		if (box) {
			const radius = 0.5 * Math.hypot(box.max[0] - box.min[0], box.max[1] - box.min[1], box.max[2] - box.min[2]);
			gain = radius * OFFSET_FACTOR;
			zGain = radius * Z_FACTOR;
		}

		let cancelled = false;
		let rafId = 0;
		let lastTs = 0;
		let stream: MediaStream | null = null;
		let video: HTMLVideoElement | null = null;
		// biome-ignore lint/suspicious/noExplicitAny: MediaPipe is loaded from CDN, so it's untyped here.
		let landmarker: any = null;
		const current = {x: 0, y: 0, z: 0}; // smoothed offset actually applied
		let baseEyeDist = 0; // inter-eye distance on the first good frame — the neutral (no-zoom) point

		// Absolute set each frame — replaces last frame's offset, so there's no drift and no fight with the
		// user's own orbiting. Offset 0 = the current view, so enabling doesn't move anything.
		const apply = () => controls.setFocalOffset(current.x * gain, current.y * gain, current.z * zGain, false);

		void (async () => {
			try {
				const vision = await import(/* @vite-ignore */ TASKS_VISION_URL);
				if (cancelled) return;
				const fileset = await vision.FilesetResolver.forVisionTasks(WASM_URL);
				if (cancelled) return;
				landmarker = await vision.FaceLandmarker.createFromOptions(fileset, {
					baseOptions: {modelAssetPath: MODEL_URL, delegate: "GPU"},
					runningMode: "VIDEO",
					numFaces: 1,
				});
				if (cancelled) return;

				stream = await navigator.mediaDevices.getUserMedia({video: {facingMode: "user"}});
				if (cancelled) {
					stream.getTracks().forEach((track) => track.stop());
					return;
				}
				video = document.createElement("video");
				video.playsInline = true;
				video.muted = true;
				video.srcObject = stream;
				await new Promise<void>((resolve) => {
					video!.onloadeddata = () => resolve();
				});
				if (cancelled) return;
				await video.play();

				const loop = () => {
					if (cancelled || !landmarker || !video) return;
					const ts = Math.max(performance.now(), lastTs + 1); // detectForVideo needs increasing ts
					lastTs = ts;
					let hx = 0;
					let hy = 0;
					let hz = 0;
					try {
						const face = landmarker.detectForVideo(video, ts).faceLandmarks?.[0];
						if (face) {
							const r = face[R_EYE_OUTER];
							const l = face[L_EYE_OUTER];
							const mx = (r.x + l.x) * 0.5; // eye midpoint, normalized image coords [0,1]
							const my = (r.y + l.y) * 0.5;
							hx = MIRROR_X * (0.5 - mx) * 2; // head-right → +x
							hy = INVERT_Y * (0.5 - my) * 2; // head-up → +y
							const eyeDist = Math.hypot(r.x - l.x, r.y - l.y); // grows as the head leans in
							if (!baseEyeDist) baseEyeDist = eyeDist;
							hz = INVERT_Z * ((eyeDist - baseEyeDist) / baseEyeDist); // >0 = leaning in
							if (Math.abs(hx) < DEADZONE) hx = 0;
							if (Math.abs(hy) < DEADZONE) hy = 0;
						}
					} catch {
						// A dropped detection frame — ease toward neutral this tick.
					}
					current.x += (clamp(hx) - current.x) * SMOOTH;
					current.y += (clamp(hy) - current.y) * SMOOTH;
					current.z += (clamp(hz) - current.z) * SMOOTH;
					apply();
					rafId = requestAnimationFrame(loop);
				};
				rafId = requestAnimationFrame(loop);
			} catch (error) {
				console.error("[head-parallax] init failed (camera blocked or model unreachable):", error);
			}
		})();

		return () => {
			cancelled = true;
			cancelAnimationFrame(rafId);
			stream?.getTracks().forEach((track) => track.stop()); // turn the webcam OFF
			if (video) {
				video.pause();
				video.srcObject = null;
			}
			landmarker?.close?.();
			controls.setFocalOffset(0, 0, 0, false); // restore the view — zero residual
		};
	}, [enabled, state.status, api]);
}
