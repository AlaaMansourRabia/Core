// BIM scene painting for the 4D timeline. Drives the ThatOpen Fragments model directly:
// resolves each schedule object's IFC GUIDs to per-model localIds, then per day reveals /
// highlights / hides exactly those elements so the building assembles itself as days advance.
//
// Element addressing (from the viewer architecture): model.getLocalIdsByGuids(guids) →
// localIds; paint via model.highlight(ids, material) / model.resetHighlight(ids) and
// OBC.Hider.set(visible, {[modelId]: Set<localId>}); always fragments.core.update(true) to repaint.

import type {MaterialDefinition} from "@thatopen/fragments";
import type {ObjectState, ScheduleObject} from "./types";

import * as OBC from "@thatopen/components";
import * as THREE from "three";

import {tradeColor} from "./trades";
import {objectStateAt} from "./types";

/** Objects being worked glow in their trade colour. Materials are cached per colour so playback
 *  doesn't churn THREE.Color allocations each frame. */
const MATERIAL_CACHE = new Map<string, MaterialDefinition>();
function materialFor(color: string): MaterialDefinition {
	let mat = MATERIAL_CACHE.get(color);
	if (!mat) {
		mat = {
			color: new THREE.Color(color),
			renderedFaces: 0,
			opacity: 1,
			transparent: false,
			preserveOriginalMaterial: false,
		} as unknown as MaterialDefinition;
		MATERIAL_CACHE.set(color, mat);
	}
	return mat;
}

/** Resolved geometry: schedule object id → the model localIds of its IFC elements. */
export interface ResolvedScene {
	modelId: string;
	model: {
		modelId: string;
		highlight(localIds: number[] | undefined, material: MaterialDefinition): Promise<void>;
		resetHighlight(localIds?: number[]): Promise<void>;
	};
	byObject: Map<string, number[]>;
	allWorked: number[];
}

function firstModel(components: OBC.Components) {
	const fragments = components.get(OBC.FragmentsManager);
	const model = [...fragments.list.values()][0];
	return {fragments, model};
}

/** Resolve every geometry-bearing object's GUIDs to localIds (once, on model ready). */
export async function resolveScene(components: OBC.Components, objects: ScheduleObject[]): Promise<ResolvedScene | null> {
	const {model} = firstModel(components);
	if (!model) return null;
	const byObject = new Map<string, number[]>();
	const allWorked: number[] = [];
	for (const obj of objects) {
		if (obj.guids.length === 0) continue;
		const raw = await model.getLocalIdsByGuids(obj.guids);
		const ids = raw.filter((x): x is number => typeof x === "number");
		if (ids.length) {
			byObject.set(obj.id, ids);
			allWorked.push(...ids);
		}
	}
	return {modelId: model.modelId, model: model as unknown as ResolvedScene["model"], byObject, allWorked};
}

/** Diff-based paint of a single day. Returns the new per-object state map; only elements whose
 *  object changed state since `prev` are touched, so scrubbing/playback stays cheap. */
export async function paintDay(
	components: OBC.Components,
	scene: ResolvedScene,
	objects: ScheduleObject[],
	day: number,
	prev: Map<string, ObjectState>,
): Promise<Map<string, ObjectState>> {
	const next = new Map<string, ObjectState>();
	const hideIds: number[] = [];
	const showIds: number[] = [];
	const resetIds: number[] = [];
	const activeByColor = new Map<string, number[]>(); // trade colour → localIds under construction

	for (const obj of objects) {
		const ids = scene.byObject.get(obj.id);
		if (!ids || ids.length === 0) continue; // non-geometry (SITE / SYSTEM) objects
		const st = objectStateAt(obj, day);
		next.set(obj.id, st);
		if (prev.get(obj.id) === st) continue; // unchanged — skip
		if (st === "pending") {
			hideIds.push(...ids);
			resetIds.push(...ids); // drop any lingering highlight so it comes back clean
		} else if (st === "active") {
			showIds.push(...ids);
			const color = tradeColor(obj.activity);
			const bucket = activeByColor.get(color) ?? [];
			bucket.push(...ids);
			activeByColor.set(color, bucket);
		} else {
			showIds.push(...ids); // built → solid (reverts to the model's real material)
			resetIds.push(...ids);
		}
	}

	const hider = components.get(OBC.Hider);
	const {fragments} = firstModel(components);
	if (resetIds.length) await scene.model.resetHighlight(resetIds);
	for (const [color, ids] of activeByColor) await scene.model.highlight(ids, materialFor(color));
	if (hideIds.length) await hider.set(false, {[scene.modelId]: new Set(hideIds)});
	if (showIds.length) await hider.set(true, {[scene.modelId]: new Set(showIds)});
	if (hideIds.length || showIds.length || activeByColor.size || resetIds.length) {
		await fragments.core.update(true);
	}
	return next;
}

/** Restore the model to its normal, fully-visible, un-highlighted state (on exit/teardown). */
export async function restoreScene(components: OBC.Components, scene: ResolvedScene | null): Promise<void> {
	const hider = components.get(OBC.Hider);
	const {fragments} = firstModel(components);
	if (scene) await scene.model.resetHighlight(scene.allWorked);
	await hider.set(true); // reveal everything
	await fragments.core.update(true);
}

// ── One-off element highlight (clicking a schedule item) ─────────────────────────────────────────────
// Independent of the day-by-day painter: paint exactly one object's IFC elements a highlight colour,
// clearing whatever was highlighted before. Used when a schedule row is clicked, so that item lights up
// on the model.

type HighlightModel = {
	getLocalIdsByGuids(guids: string[]): Promise<(number | null)[]>;
	highlight(localIds: number[], material: MaterialDefinition): Promise<void>;
	resetHighlight(localIds?: number[]): Promise<void>;
};

/** Highlight the elements for the given IFC GUIDs, clearing any previously-highlighted ids. Returns the
 *  localIds now highlighted (pass back as `prev` next time to clear them). */
export async function highlightElements(
	components: OBC.Components,
	guids: string[],
	color: string,
	prev: number[] | null,
): Promise<number[]> {
	const {fragments, model} = firstModel(components);
	if (!model) return prev ?? [];
	const m = model as unknown as HighlightModel;
	if (prev && prev.length) await m.resetHighlight(prev);
	const raw = await m.getLocalIdsByGuids(guids);
	const ids = raw.filter((x): x is number => typeof x === "number");
	if (ids.length) await m.highlight(ids, materialFor(color));
	await fragments.core.update(true);
	return ids;
}

/** Clear a one-off highlight (on teardown / deselect). */
export async function clearHighlightedElements(components: OBC.Components, prev: number[] | null): Promise<void> {
	if (!prev || !prev.length) return;
	const {fragments, model} = firstModel(components);
	if (!model) return;
	await (model as unknown as HighlightModel).resetHighlight(prev);
	await fragments.core.update(true);
}
