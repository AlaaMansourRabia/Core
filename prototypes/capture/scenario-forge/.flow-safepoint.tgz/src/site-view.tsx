import type {CSSProperties} from "react";

import {cn} from "@wakecap/core-utils";
import {Button} from "@wakecap/core-ui/button";
import {WeekSelector, type WeekSelectorWeek} from "@wakecap/core-ui/week-selector";
import {ArrowLeft, Expand} from "lucide-react";
import {useEffect, useRef, useState} from "react";

import {CesiumCanvas} from "./cesium-canvas";
import {getFloorByLevel} from "./floor-panel";
import {SingleHouseView} from "./house-view";

type Phase = "idle" | "loading" | "revealing" | "exit-start" | "exit";

// Villa header content (Capture Admin redesign). The site path + villa name mirror the villa inspector;
// the weeks feed the header's date-range label + week navigator (W112 is the active program week).
const VILLA_NAME = "Villa 1234";
const SITE_BREADCRUMB = "ALMANAR – Phase 1 – Zone 1 | Phase 1 | Zone 1-A";
const HEADER_WEEKS: WeekSelectorWeek[] = [
	{value: "W109", start: new Date(2026, 5, 12), end: new Date(2026, 5, 18)},
	{value: "W110", start: new Date(2026, 5, 19), end: new Date(2026, 5, 25)},
	{value: "W111", start: new Date(2026, 5, 26), end: new Date(2026, 6, 2)},
	{value: "W112", start: new Date(2026, 6, 3), end: new Date(2026, 6, 9)},
	{value: "W113", start: new Date(2026, 6, 10), end: new Date(2026, 6, 16)},
	{value: "W114", start: new Date(2026, 6, 17), end: new Date(2026, 6, 23)},
];

/**
 * The Site workspace: the Cesium showcase (map) with a click-into-a-part → house-level BIM transition.
 *
 * Clicking a model part in the Cesium view posts its floor up to us (see public/showcase/index.html);
 * we mount the house-level 3D underneath, zoom + fade the map toward the clicked point while the 3D
 * loads, then dissolve into it — the same motion the old neighborhood used — with the clicked floor
 * preselected. A back button reverses the transition.
 */
export function SiteView() {
	const [view, setView] = useState<"map" | "house">("map");
	const [phase, setPhase] = useState<Phase>("idle");
	const [floorId, setFloorId] = useState<string | null>(null);
	const [origin, setOrigin] = useState<{x: number; y: number} | null>(null);
	// Header week navigator (Capture Admin redesign) — drives the date-range label shown in the header.
	const [week, setWeek] = useState("W112");

	// The villa header's expand button toggles browser full-screen on the whole Site workspace.
	const rootRef = useRef<HTMLDivElement>(null);
	const toggleFullscreen = () => {
		const el = rootRef.current;
		if (!el) return;
		if (document.fullscreenElement) void document.exitFullscreen();
		else void el.requestFullscreen?.();
	};

	const revealingRef = useRef(false);
	const minHeldRef = useRef(false); // the slow zoom has read for a beat
	const settledRef = useRef(false); // the 3D has loaded (or errored)
	const minTimer = useRef<number | undefined>(undefined);
	const safetyTimer = useRef<number | undefined>(undefined);
	const settleTimer = useRef<number | undefined>(undefined);

	// Finish the zoom and fade the map out in one motion, then commit to the house view.
	const beginReveal = () => {
		if (revealingRef.current) return;
		revealingRef.current = true;
		window.clearTimeout(minTimer.current);
		window.clearTimeout(safetyTimer.current);
		setPhase("revealing");
		settleTimer.current = window.setTimeout(() => {
			setView("house");
			setPhase("idle");
			revealingRef.current = false;
		}, 650);
	};
	const maybeReveal = () => {
		if (minHeldRef.current && settledRef.current) beginReveal();
	};

	// A part was clicked: mount the house 3D underneath (it starts loading at once) and begin the slow
	// zoom toward the clicked point. A safety net reveals anyway if the model never reports back.
	const enterHouse = (nextFloorId: string | null, point: {x: number; y: number} | null) => {
		setFloorId(nextFloorId);
		setOrigin(point);
		revealingRef.current = false;
		minHeldRef.current = false;
		settledRef.current = false;
		window.clearTimeout(minTimer.current);
		window.clearTimeout(safetyTimer.current);
		window.clearTimeout(settleTimer.current);
		setPhase("loading");
		minTimer.current = window.setTimeout(() => {
			minHeldRef.current = true;
			maybeReveal();
		}, 420);
		safetyTimer.current = window.setTimeout(beginReveal, 8000);
	};

	const handleHouseSettled = () => {
		settledRef.current = true;
		maybeReveal();
	};

	// Mirror of enter: put the map back on top zoomed-in + transparent, then zoom it out and fade it in
	// over the house, pivoting on the same point. The house stays mounted underneath until it settles.
	const exitHouse = () => {
		window.clearTimeout(minTimer.current);
		window.clearTimeout(safetyTimer.current);
		window.clearTimeout(settleTimer.current);
		revealingRef.current = false;
		minHeldRef.current = false;
		settledRef.current = false;
		setView("map");
		setPhase("exit-start");
		safetyTimer.current = window.setTimeout(() => setPhase("exit"), 30);
		settleTimer.current = window.setTimeout(() => {
			setPhase("idle");
			setOrigin(null);
		}, 700);
	};

	// A part-click arrives from the Cesium iframe with the clicked floor (levelName) + point.
	useEffect(() => {
		const onMessage = (event: MessageEvent) => {
			const data = event.data as {type?: string; level?: string; point?: {x: number; y: number}} | null;
			if (!data || data.type !== "ue22-part-click") return;
			if (view === "house" || phase !== "idle") return; // ignore mid-transition / already inside
			enterHouse(getFloorByLevel(data.level)?.id ?? null, data.point ?? null);
		};
		window.addEventListener("message", onMessage);
		return () => window.removeEventListener("message", onMessage);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [view, phase]);

	useEffect(
		() => () => {
			window.clearTimeout(minTimer.current);
			window.clearTimeout(safetyTimer.current);
			window.clearTimeout(settleTimer.current);
		},
		[],
	);

	// Zoom the map toward the clicked point while it fades — ramps up through loading → revealing, and
	// mirrors on exit. (Scaling the iframe wrapper reads as a push-in toward the part you clicked.)
	const scale = phase === "revealing" || phase === "exit-start" ? 2.4 : phase === "loading" ? 1.8 : 1;
	const mapStyle: CSSProperties = {
		transformOrigin: origin ? `${origin.x}px ${origin.y}px` : "center",
		transform: `scale(${scale})`,
		opacity: phase === "revealing" || phase === "exit-start" ? 0 : 1,
		transition:
			phase === "loading"
				? "transform 3000ms ease-in"
				: phase === "revealing"
					? "transform 650ms ease-out, opacity 650ms ease-out"
					: phase === "exit"
						? "transform 650ms ease-in, opacity 650ms ease-in"
						: undefined,
	};

	return (
		<div
			ref={rootRef}
			className="wwc:relative wwc:h-full wwc:min-h-0 wwc:w-full wwc:overflow-hidden wwc:bg-background"
		>
			{/* House-level BIM view — mounted underneath as soon as a part is clicked, so its 3D loads during
			    the zoom and the map dissolves straight into it, with the clicked floor preselected. */}
			{(view === "house" || phase !== "idle") && (
				<div
					className={cn(
						"wwc:absolute wwc:inset-0 wwc:overflow-hidden",
						view === "house" ? "wwc:z-10" : "wwc:z-0",
					)}
				>
					<SingleHouseView initialFloorId={floorId} onSettled={handleHouseSettled} />
				</div>
			)}

			{/* Cesium map layer — always mounted (so it never reloads); zooms + fades during the transition. */}
			<div
				className={cn(
					"wwc:absolute wwc:inset-0 wwc:overflow-hidden",
					view === "house" ? "wwc:z-0" : "wwc:z-10",
				)}
				style={mapStyle}
				aria-hidden={view === "house"}
			>
				<CesiumCanvas />
			</div>

			{/* Villa viewer header (Capture Admin redesign) — a full-width glass bar over the 3D house view.
			    Left: a "Back to Site" pill (back to the map), the muted site breadcrumb, and the centered
			    villa title. Right: the week selector (date range + week navigator) and a full-screen expand
			    button. The scrim is pointer-events-none so canvas drags fall through; only the chips catch
			    clicks. The floor list / inspector panels below are offset to clear this bar. */}
			{view === "house" && (
				<div className="wwc:pointer-events-none wwc:absolute wwc:inset-x-0 wwc:top-0 wwc:z-30 wwc:bg-gradient-to-b wwc:from-black/5 wwc:to-transparent wwc:px-3 wwc:py-4">
					<div className="wwc:pointer-events-auto wwc:flex wwc:items-center wwc:justify-between wwc:gap-4">
						<div className="wwc:flex wwc:min-w-0 wwc:flex-1 wwc:items-center wwc:gap-6">
							<button
								type="button"
								onClick={exitHouse}
								className="wwc:flex wwc:shrink-0 wwc:items-center wwc:gap-1.5 wwc:rounded wwc:border wwc:border-border wwc:bg-background/80 wwc:px-3 wwc:py-2 wwc:text-[13px] wwc:font-medium wwc:text-foreground wwc:shadow-sm wwc:backdrop-blur wwc:transition-colors wwc:hover:bg-background"
							>
								<ArrowLeft className="wwc:h-4 wwc:w-4 wwc:opacity-50" />
								Back to Site
							</button>
							<div className="wwc:flex wwc:min-w-0 wwc:flex-1 wwc:items-center wwc:gap-6">
								<span className="wwc:shrink-0 wwc:whitespace-nowrap wwc:text-[13px] wwc:font-medium wwc:text-foreground/40">
									{SITE_BREADCRUMB}
								</span>
								<span className="wwc:min-w-0 wwc:flex-1 wwc:truncate wwc:text-center wwc:text-base wwc:font-semibold wwc:leading-tight wwc:text-foreground">
									{VILLA_NAME}
								</span>
							</div>
						</div>
						<div className="wwc:flex wwc:shrink-0 wwc:items-center wwc:gap-1">
							<WeekSelector
								bare
								className="wwc:rounded wwc:border wwc:border-border wwc:bg-background/80 wwc:px-3 wwc:py-1.5 wwc:shadow-sm wwc:backdrop-blur"
								weeks={HEADER_WEEKS}
								value={week}
								onValueChange={setWeek}
								visibleCount={4}
							/>
							<Button
								type="button"
								variant="outline"
								icon
								aria-label="Full screen"
								className="wwc:h-[46px] wwc:w-[46px] wwc:shrink-0 wwc:border-border wwc:bg-background/80 wwc:shadow-sm wwc:backdrop-blur"
								onClick={toggleFullscreen}
							>
								<Expand className="wwc:h-4 wwc:w-4" />
							</Button>
						</div>
					</div>
				</div>
			)}
		</div>
	);
}
