// The Site canvas IS the reference app: uzufly/ifc-cesium-showcase's <cesium-ifc-viewer> component
// (Cesium + web-ifc + Lit — IFC drag-and-drop, Level/Category hover tooltip, click highlight).
//
// We host the reference's *own built bundle* on OUR origin (public/showcase/, served by this dev
// server) rather than iframing uzufly's netlify deploy. Why: the ion token baked into the build is
// allow-listed for localhost but NOT the netlify domain, so from netlify every ion request 403s and
// the globe stays blank; served from localhost the same token returns 200 and the map renders. Cesium
// v1.112 assets + web-ifc wasm are served from public/showcase/static/.
//
// Drag & drop works through the frame: dropping an .ifc targets the hosted page's own document, whose
// handler parses the IFC in-browser (web-ifc) — nothing is uploaded anywhere.
const SHOWCASE_URL = "/showcase/index.html";

export function CesiumCanvas() {
	return (
		<div className="wwc:relative wwc:h-full wwc:min-h-0 wwc:w-full wwc:overflow-hidden">
			<iframe
				src={SHOWCASE_URL}
				title="uzufly IFC + Cesium showcase"
				className="wwc:absolute wwc:inset-0 wwc:h-full wwc:w-full wwc:border-0"
				allow="fullscreen"
			/>
		</div>
	);
}
